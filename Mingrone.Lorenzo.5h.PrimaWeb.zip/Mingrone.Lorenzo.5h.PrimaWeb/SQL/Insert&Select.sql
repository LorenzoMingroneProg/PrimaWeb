-- SQLite
INSERT INTO Prenotazioni ( Nome, Email)
VALUES ("Pino","Pino@insegno.it");

SELECT PrenotazioneId, Nome, Email
FROM Prenotazioni;